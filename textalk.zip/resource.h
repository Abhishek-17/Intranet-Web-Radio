//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by textalk.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TEXTALTYPE                  129
#define IDI_ICON1                       131
#define IDI_ICON2                       132
#define IDC_CHECK1                      1000
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define IDC_EDIT6                       1007
#define IDC_EDIT7                       1008
#define IDC_EDIT8                       1009
#define ID_BUTTON32771                  32771
#define ID_BUTTON32772                  32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
