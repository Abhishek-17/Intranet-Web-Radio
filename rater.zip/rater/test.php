<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> New Document </title>
<meta name="Author" content="">
<meta name="Keywords" content="">
<meta name="Description" content="">
</head>

<body>

<?
$rater_id=1;
$rater_item_name='Item 1';
include("rater.php");
?>

<?
$rater_id=2;
$rater_item_name='Item 2';
include("rater.php");
?>

</body>
</html>
